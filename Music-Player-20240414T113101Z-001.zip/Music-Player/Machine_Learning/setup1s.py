import tkinter as tk
import numpy as np
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression

def select_parameter_to_predict():
    root = tk.Tk()
    root.title("Parametre Seçimi")

    choice = None

    def set_choice(option):
        nonlocal choice
        choice = option
        root.quit()  # Kapatma yerine root'un döngüsünü durdur

    tk.Label(root, text="Hangi parametreyi tahmin etmek istiyorsunuz?").pack()

    tk.Button(root, text="e+P", command=lambda: set_choice('e+P')).pack()
    tk.Button(root, text="pi+P", command=lambda: set_choice('pi+P')).pack()
    tk.Button(root, text="P+P", command=lambda: set_choice('P+P')).pack()
    tk.Button(root, text="K+P", command=lambda: set_choice('K+P')).pack()

    root.mainloop()

    return choice

def epregressor():
    root = tk.Tk()
    root.title("Parametre Girisi")

    # Verileri tanımlama
    data = {
        "e+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "pi+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "pi+P": [0.12, 0.35, 0.47, 0.50, 0.48, 0.40, 0.36, 0.28, 0.20, 0.16],
        "K+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "K+P": [0.00, 0.01, 0.02, 0.02, 0.02, 0.03, 0.02, 0.01, 0.00, 0.00],
        "P+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "P+P": [0.12, 0.12, 0.14, 0.24, 0.34, 0.44, 0.54, 0.66, 0.77, 0.83]
    }

    df1 = pd.DataFrame(data)

    data2 = {
        "e+P": [0.58, 0.31, 0.18, 0.10, 0.06, 0.05, 0.04, 0.03, 0.03, 0.03]
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    def predict():
        new_variables = [float(entry.get()) for entry in entries]
        X_new = np.array(new_variables).reshape(1, -1)

        # Yeni bağımsız değişkenlerle tahmin yapma
        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
        df_new_data = pd.DataFrame(X_new, columns=df1.columns)
        df_new_results = pd.DataFrame({'e+P': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        # Sonuçları yazdırma
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, df_combined_results.to_string(index=False))

    entries = []
    for col in df1.columns:
        frame = tk.Frame(root)
        frame.pack()
        tk.Label(frame, text=col).pack(side=tk.LEFT)
        entry = tk.Entry(frame)
        entry.pack(side=tk.LEFT)
        entries.append(entry)

    tk.Button(root, text="Tahmin Et", command=predict).pack()

    result_text = tk.Text(root)
    result_text.pack()

    root.mainloop()

def pipregressor():
    root = tk.Tk()
    root.title("Parametre Girisi")

    # Verileri tanımlama
    data = {
        "e+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "e+P": [0.58, 0.31, 0.18, 0.10, 0.06, 0.05, 0.04, 0.03, 0.03, 0.03],
        "pi+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "K+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "K+P": [0.00, 0.01, 0.02, 0.02, 0.02, 0.03, 0.02, 0.01, 0.00, 0.00],
        "P+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "P+P": [0.12, 0.12, 0.14, 0.24, 0.34, 0.44, 0.54, 0.66, 0.77, 0.83]
    }

    df1 = pd.DataFrame(data)

    data2 = {
        "pi+P": [0.12, 0.35, 0.47, 0.50, 0.48, 0.40, 0.36, 0.28, 0.20, 0.16],
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    def predict():
        new_variables = [float(entry.get()) for entry in entries]
        X_new = np.array(new_variables).reshape(1, -1)

        # Yeni bağımsız değişkenlerle tahmin yapma
        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
        df_new_data = pd.DataFrame(X_new, columns=df1.columns)
        df_new_results = pd.DataFrame({'pi+P': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        # Sonuçları yazdırma
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, df_combined_results.to_string(index=False))

    entries = []
    for col in df1.columns:
        frame = tk.Frame(root)
        frame.pack()
        tk.Label(frame, text=col).pack(side=tk.LEFT)
        entry = tk.Entry(frame)
        entry.pack(side=tk.LEFT)
        entries.append(entry)

    tk.Button(root, text="Tahmin Et", command=predict).pack()

    result_text = tk.Text(root)
    result_text.pack()

    root.mainloop()

def ppregressor():
    root = tk.Tk()
    root.title("Parametre Girisi")

    # Verileri tanımlama
    data = {
        "e+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "e+P": [0.58, 0.31, 0.18, 0.10, 0.06, 0.05, 0.04, 0.03, 0.03, 0.03],
        "pi+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "pi+P": [0.12, 0.35, 0.47, 0.50, 0.48, 0.40, 0.36, 0.28, 0.20, 0.16],
        "K+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "K+P": [0.00, 0.01, 0.02, 0.02, 0.02, 0.03, 0.02, 0.01, 0.00, 0.00],
        "P+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    }

    df1 = pd.DataFrame(data)

    data2 = {
        "P+P": [0.12, 0.12, 0.14, 0.24, 0.34, 0.44, 0.54, 0.66, 0.77, 0.83],
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    def predict():
        new_variables = [float(entry.get()) for entry in entries]
        X_new = np.array(new_variables).reshape(1, -1)

        # Yeni bağımsız değişkenlerle tahmin yapma
        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
        df_new_data = pd.DataFrame(X_new, columns=df1.columns)
        df_new_results = pd.DataFrame({'P+P': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        # Sonuçları yazdırma
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, df_combined_results.to_string(index=False))

    entries = []
    for col in df1.columns:
        frame = tk.Frame(root)
        frame.pack()
        tk.Label(frame, text=col).pack(side=tk.LEFT)
        entry = tk.Entry(frame)
        entry.pack(side=tk.LEFT)
        entries.append(entry)

    tk.Button(root, text="Tahmin Et", command=predict).pack()

    result_text = tk.Text(root)
    result_text.pack()

    root.mainloop()

def kpregressor():
    root = tk.Tk()
    root.title("Parametre Girisi")

    # Verileri tanımlama
    data = {
        "e+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "e+P": [0.58, 0.31, 0.18, 0.10, 0.06, 0.05, 0.04, 0.03, 0.03, 0.03],
        "pi+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "pi+P": [0.12, 0.35, 0.47, 0.50, 0.48, 0.40, 0.36, 0.28, 0.20, 0.16],
        "K+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "P+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "P+P": [0.12, 0.12, 0.14, 0.24, 0.34, 0.44, 0.54, 0.66, 0.77, 0.83]
    }

    df1 = pd.DataFrame(data)

    data2 = {
        "K+P": [0.00, 0.01, 0.02, 0.02, 0.02, 0.03, 0.02, 0.01, 0.00, 0.00],
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    def predict():
        new_variables = [float(entry.get()) for entry in entries]
        X_new = np.array(new_variables).reshape(1, -1)

        # Yeni bağımsız değişkenlerle tahmin yapma
        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
        df_new_data = pd.DataFrame(X_new, columns=df1.columns)
        df_new_results = pd.DataFrame({'K+P': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        # Sonuçları yazdırma
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, df_combined_results.to_string(index=False))

    entries = []
    for col in df1.columns:
        frame = tk.Frame(root)
        frame.pack()
        tk.Label(frame, text=col).pack(side=tk.LEFT)
        entry = tk.Entry(frame)
        entry.pack(side=tk.LEFT)
        entries.append(entry)

    tk.Button(root, text="Tahmin Et", command=predict).pack()

    result_text = tk.Text(root)
    result_text.pack()

    root.mainloop()

selected_parameter = select_parameter_to_predict()

if selected_parameter is not None:  # Bir seçim yapıldıysa
    if selected_parameter == 'e+P':
        epregressor()
    elif selected_parameter == 'pi+P':
        pipregressor()
    elif selected_parameter == 'P+P':
        ppregressor()
    elif selected_parameter == 'K+P':
        kpregressor()
