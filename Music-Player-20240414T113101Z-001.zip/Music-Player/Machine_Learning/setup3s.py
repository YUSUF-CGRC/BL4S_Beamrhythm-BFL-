import tkinter as tk
import numpy as np
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression

def select_parameter_to_predict():
    root = tk.Tk()
    root.title("Parametre Seçimi")

    choice = None

    def set_choice(option):
        nonlocal choice
        choice = option
        root.quit()  # Kapatma yerine root'un döngüsünü durdur

    tk.Label(root, text="Hangi parametreyi tahmin etmek istiyorsunuz?").pack()

    tk.Button(root, text="e+S", command=lambda: set_choice('e+S')).pack()
    tk.Button(root, text="pi+S", command=lambda: set_choice('pi+S')).pack()
    tk.Button(root, text="K+S", command=lambda: set_choice('K+S')).pack()
    tk.Button(root, text="P+S", command=lambda: set_choice('P+S')).pack()

    root.mainloop()

    return choice

def epregressor():
    root = tk.Tk()
    root.title("Parametre Girisi")

    # Verileri tanımlama
    data = {
        "e+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "P+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "P+S": [6750, 21500, 67500, 100000, 225000, 260000, 275000, 290000, 300000, 500000],
        "pi+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "pi+S": [10000, 67000, 100000, 22500, 225000, 280000, 280000, 270000, 270000, 260000],
        "K+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "K+S": [1000, 120000, 225000, 22500, 22500, 250000, 260000, 265000, 265000, 260000]
    }

    df1 = pd.DataFrame(data)

    data2 = {
                "e+S": [22500, 4500, 22300, 22000, 10000, 9000, 8000, 6750, 5000, 3000]
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    def predict():
        new_variables = [float(entry.get()) for entry in entries]
        X_new = np.array(new_variables).reshape(1, -1)

        # Yeni bağımsız değişkenlerle tahmin yapma
        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
        df_new_data = pd.DataFrame(X_new, columns=df1.columns)
        df_new_results = pd.DataFrame({'e+P': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        # Sonuçları yazdırma
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, df_combined_results.to_string(index=False))

    entries = []
    for col in df1.columns:
        frame = tk.Frame(root)
        frame.pack()
        tk.Label(frame, text=col).pack(side=tk.LEFT)
        entry = tk.Entry(frame)
        entry.pack(side=tk.LEFT)
        entries.append(entry)

    tk.Button(root, text="Tahmin Et", command=predict).pack()

    result_text = tk.Text(root)
    result_text.pack()

    root.mainloop()

def pipregressor():
    root = tk.Tk()
    root.title("Parametre Girisi")

    # Verileri tanımlama
    data = {
        "e+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "e+S": [22500, 4500, 22300, 22000, 10000, 9000, 8000, 6750, 5000, 3000],
        "P+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "P+S": [6750, 21500, 67500, 100000, 225000, 260000, 275000, 290000, 300000, 500000],
        "pi+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "K+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "K+S": [1000, 120000, 225000, 22500, 22500, 250000, 260000, 265000, 265000, 260000]

    }

    df1 = pd.DataFrame(data)

    data2 = {
        "pi+S": [10000, 67000, 100000, 22500, 225000, 280000, 280000, 270000, 270000, 260000],
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    def predict():
        new_variables = [float(entry.get()) for entry in entries]
        X_new = np.array(new_variables).reshape(1, -1)

        # Yeni bağımsız değişkenlerle tahmin yapma
        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
        df_new_data = pd.DataFrame(X_new, columns=df1.columns)
        df_new_results = pd.DataFrame({'pi+P': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        # Sonuçları yazdırma
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, df_combined_results.to_string(index=False))

    entries = []
    for col in df1.columns:
        frame = tk.Frame(root)
        frame.pack()
        tk.Label(frame, text=col).pack(side=tk.LEFT)
        entry = tk.Entry(frame)
        entry.pack(side=tk.LEFT)
        entries.append(entry)

    tk.Button(root, text="Tahmin Et", command=predict).pack()

    result_text = tk.Text(root)
    result_text.pack()

    root.mainloop()


def kpregressor():
    root = tk.Tk()
    root.title("Parametre Girisi")

    # Verileri tanımlama
    data = {
        "e+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "e+S": [22500, 4500, 22300, 22000, 10000, 9000, 8000, 6750, 5000, 3000],
        "P+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "P+S": [6750, 21500, 67500, 100000, 225000, 260000, 275000, 290000, 300000, 500000],
        "pi+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "pi+S": [10000, 67000, 100000, 22500, 225000, 280000, 280000, 270000, 270000, 260000],
        "K+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],

    }

    df1 = pd.DataFrame(data)

    data2 = {
        "K+S": [1000, 120000, 225000, 22500, 22500, 250000, 260000, 265000, 265000, 260000],
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    def predict():
        new_variables = [float(entry.get()) for entry in entries]
        X_new = np.array(new_variables).reshape(1, -1)

        # Yeni bağımsız değişkenlerle tahmin yapma
        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
        df_new_data = pd.DataFrame(X_new, columns=df1.columns)
        df_new_results = pd.DataFrame({'K+P': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        # Sonuçları yazdırma
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, df_combined_results.to_string(index=False))

    entries = []
    for col in df1.columns:
        frame = tk.Frame(root)
        frame.pack()
        tk.Label(frame, text=col).pack(side=tk.LEFT)
        entry = tk.Entry(frame)
        entry.pack(side=tk.LEFT)
        entries.append(entry)

    tk.Button(root, text="Tahmin Et", command=predict).pack()

    result_text = tk.Text(root)
    result_text.pack()

    root.mainloop()



def Ppregressor():
    root = tk.Tk()
    root.title("Parametre Girisi")

    # Verileri tanımlama
    data = {
        "e+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "e+S": [22500, 4500, 22300, 22000, 10000, 9000, 8000, 6750, 5000, 3000],
        "P+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "pi+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "pi+S": [10000, 67000, 100000, 22500, 225000, 280000, 280000, 270000, 270000, 260000],
        "K+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "K+S": [1000, 120000, 225000, 22500, 22500, 250000, 260000, 265000, 265000, 260000]

    }

    df1 = pd.DataFrame(data)

    data2 = {
        "P+S": [6750, 21500, 67500, 100000, 225000, 260000, 275000, 290000, 300000, 500000],
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    def predict():
        new_variables = [float(entry.get()) for entry in entries]
        X_new = np.array(new_variables).reshape(1, -1)

        # Yeni bağımsız değişkenlerle tahmin yapma
        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
        df_new_data = pd.DataFrame(X_new, columns=df1.columns)
        df_new_results = pd.DataFrame({'K+P': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        # Sonuçları yazdırma
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, df_combined_results.to_string(index=False))

    entries = []
    for col in df1.columns:
        frame = tk.Frame(root)
        frame.pack()
        tk.Label(frame, text=col).pack(side=tk.LEFT)
        entry = tk.Entry(frame)
        entry.pack(side=tk.LEFT)
        entries.append(entry)

    tk.Button(root, text="Tahmin Et", command=predict).pack()

    result_text = tk.Text(root)
    result_text.pack()

    root.mainloop()

selected_parameter = select_parameter_to_predict()

if selected_parameter is not None:  # Bir seçim yapıldıysa
    if selected_parameter == 'e+S':
        epregressor()
    elif selected_parameter == 'pi+S':
        pipregressor()
    elif selected_parameter == 'K+S':
        kpregressor()
    elif selected_parameter == 'P+S':
        Ppregressor()