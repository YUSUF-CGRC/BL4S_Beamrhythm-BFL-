import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import numpy as np
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression

def tahmin_sorusu():
    root = tk.Tk()
    root.title("Parametre Tahmini")

    label = ttk.Label(root, text="Hangi parametreyi tahmin etmek istersiniz?")
    label.grid(row=0, column=0, padx=10, pady=10)

    options = ['e+S', 'P+S', 'pi+S', 'K+S']
    chosen_option = tk.StringVar()
    option_menu = ttk.OptionMenu(root, chosen_option, options[0], *options)
    option_menu.grid(row=0, column=1, padx=10, pady=10)

    button = ttk.Button(root, text="Tahmin Et", command=lambda: tahmin_yap(chosen_option.get(), root))
    button.grid(row=1, columnspan=2, padx=10, pady=10)

    root.mainloop()

def tahmin_yap(secim, root):
    try:
        if secim == 'e+S':
            sonuc = esregressor(root)
        elif secim == 'P+S':
            sonuc = psregressor(root)
        elif secim == 'pi+S':
            sonuc = pisregressor(root)
        elif secim == 'K+S':
            sonuc = ksregressor(root)
        else:
            messagebox.showerror("Hata", "Geçersiz seçenek!")
            return

        result_window = tk.Toplevel(root)
        result_window.title("Tahmin Sonuçları")

        result_label = ttk.Label(result_window, text=sonuc)
        result_label.pack(padx=10, pady=10)

    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")

def esregressor(root):
    data = {
        'e+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'P+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'P+S': [0.5, 100.0, 300.0, 500.0, 550.0, 575.0, 450.0, 350.0, 225.0, 100.0, 50.0],
        'pi+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'pi+S': [7500, 22500, 80000, 100000, 150000, 160000, 155000, 135000, 112500, 99000, 85000],
        'K+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'K+S': [600, 3000, 7500, 9000, 10000, 11000, 9500, 8750, 7300, 7600, 5750]
    }

    df = pd.DataFrame(data)

    data2 = {
        'e+S': [22500, 23000, 22500, 23750, 12500, 8500, 7000, 5750, 4250, 2000, 1175],
    }
    df2 = pd.DataFrame(data2)
    X = df.values
    y = df2.values

    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    model = LinearRegression()
    model.fit(X_poly, y)

    root.withdraw()  # Ana pencereyi gizle
    es_window = tk.Toplevel(root)
    es_window.title("e+S Parametre Tahmini")

    variables = {}
    for col in df.columns:
        label = ttk.Label(es_window, text=f"{col}: ")
        label.grid(sticky="w", padx=10, pady=5)

        entry = ttk.Entry(es_window)
        entry.grid(row=df.columns.get_loc(col), column=1, padx=10, pady=5)

        variables[col] = entry

    def predict():
        new_variables = []
        for col, entry in variables.items():
            try:
                value = float(entry.get())
            except ValueError:
                messagebox.showerror("Hata", "Geçersiz giriş!")
                return
            new_variables.append(value)
        X_new = np.array(new_variables).reshape(1, -1)

        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        df_new_data = pd.DataFrame(X_new, columns=df.columns)
        df_new_results = pd.DataFrame({'e+S': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        result_window = tk.Toplevel(root)
        result_window.title("Tahmin Sonuçları")

        result_label = ttk.Label(result_window, text=df_combined_results)
        result_label.pack(padx=10, pady=10)

    predict_button = ttk.Button(es_window, text="Tahmin Et", command=predict)
    predict_button.grid(row=len(df.columns), columnspan=2, padx=10, pady=10)

def psregressor(root):
    data = {
        'e+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'e+S': [22500, 23000, 22500, 23750, 12500, 8500, 7000, 5750, 4250, 2000, 1175],
        'P+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'pi+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'pi+S': [7500, 22500, 80000, 100000, 150000, 160000, 155000, 135000, 112500, 99000, 85000],
        'K+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'K+S': [600, 3000, 7500, 9000, 10000, 11000, 9500, 8750, 7300, 7600, 5750]
    }
    df = pd.DataFrame(data)

    data2 = {
         'P+S': [0.5, 100.0, 300.0, 500.0, 550.0, 575.0, 450.0, 350.0, 225.0, 100.0, 50.0],
    }
    df2 = pd.DataFrame(data2)

    X = df.values
    y = df2.values

    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    model = LinearRegression()
    model.fit(X_poly, y)

    root.withdraw()  # Ana pencereyi gizle
    ps_window = tk.Toplevel(root)
    ps_window.title("P+S Parametre Tahmini")

    variables = {}
    for col in df.columns:
        label = ttk.Label(ps_window, text=f"{col}: ")
        label.grid(sticky="w", padx=10, pady=5)

        entry = ttk.Entry(ps_window)
        entry.grid(row=df.columns.get_loc(col), column=1, padx=10, pady=5)

        variables[col] = entry

    def predict():
        new_variables = []
        for col, entry in variables.items():
            try:
                value = float(entry.get())
            except ValueError:
                messagebox.showerror("Hata", "Geçersiz giriş!")
                return
            new_variables.append(value)
        X_new = np.array(new_variables).reshape(1, -1)

        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        df_new_data = pd.DataFrame(X_new, columns=df.columns)
        df_new_results = pd.DataFrame({'P+S': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        result_window = tk.Toplevel(root)
        result_window.title("Tahmin Sonuçları")

        result_label = ttk.Label(result_window, text=df_combined_results)
        result_label.pack(padx=10, pady=10)

    predict_button = ttk.Button(ps_window, text="Tahmin Et", command=predict)
    predict_button.grid(row=len(df.columns), columnspan=2, padx=10, pady=10)

def pisregressor(root):
    data = {
        'e+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'e+S': [22500, 23000, 22500, 23750, 12500, 8500, 7000, 5750, 4250, 2000, 1175],
        'P+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'P+S': [0.5, 100.0, 300.0, 500.0, 550.0, 575.0, 450.0, 350.0, 225.0, 100.0, 50.0],
        'pi+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'K+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'K+S': [600, 3000, 7500, 9000, 10000, 11000, 9500, 8750, 7300, 7600, 5750]
    }

    df = pd.DataFrame(data)

    data2 = {
       'pi+S': [7500, 22500, 80000, 100000, 150000, 160000, 155000, 135000, 112500, 99000, 85000],
    }

    df2 = pd.DataFrame(data2)

    X = df.values
    y = df2.values

    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    model = LinearRegression()
    model.fit(X_poly, y)

    root.withdraw()  # Ana pencereyi gizle
    pis_window = tk.Toplevel(root)
    pis_window.title("pi+S Parametre Tahmini")

    variables = {}
    for col in df.columns:
        label = ttk.Label(pis_window, text=f"{col}: ")
        label.grid(sticky="w", padx=10, pady=5)

        entry = ttk.Entry(pis_window)
        entry.grid(row=df.columns.get_loc(col), column=1, padx=10, pady=5)

        variables[col] = entry

    def predict():
        new_variables = []
        for col, entry in variables.items():
            try:
                value = float(entry.get())
            except ValueError:
                messagebox.showerror("Hata", "Geçersiz giriş!")
                return
            new_variables.append(value)
        X_new = np.array(new_variables).reshape(1, -1)

        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        df_new_data = pd.DataFrame(X_new, columns=df.columns)
        df_new_results = pd.DataFrame({'pi+S': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        result_window = tk.Toplevel(root)
        result_window.title("Tahmin Sonuçları")

        result_label = ttk.Label(result_window, text=df_combined_results)
        result_label.pack(padx=10, pady=10)

    predict_button = ttk.Button(pis_window, text="Tahmin Et", command=predict)
    predict_button.grid(row=len(df.columns), columnspan=2, padx=10, pady=10)

def ksregressor(root):
    data = {
        'e+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'e+S': [22500, 23000, 22500, 23750, 12500, 8500, 7000, 5750, 4250, 2000, 1175],
        'P+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'P+S': [0.5, 100.0, 300.0, 500.0, 550.0, 575.0, 450.0, 350.0, 225.0, 100.0, 50.0],
        'pi+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'pi+S': [7500, 22500, 80000, 100000, 150000, 160000, 155000, 135000, 112500, 99000, 85000],
        'K+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
    }

    df = pd.DataFrame(data)

    data2 = {
       'K+S': [600, 3000, 7500, 9000, 10000, 11000, 9500, 8750, 7300, 7600, 5750],
    }

    df2 = pd.DataFrame(data2)

    X = df.values
    y = df2.values

    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    model = LinearRegression()
    model.fit(X_poly, y)

    root.withdraw()  # Ana pencereyi gizle
    ks_window = tk.Toplevel(root)
    ks_window.title("K+S Parametre Tahmini")

    variables = {}
    for col in df.columns:
        label = ttk.Label(ks_window, text=f"{col}: ")
        label.grid(sticky="w", padx=10, pady=5)

        entry = ttk.Entry(ks_window)
        entry.grid(row=df.columns.get_loc(col), column=1, padx=10, pady=5)

        variables[col] = entry

    def predict():
        new_variables = []
        for col, entry in variables.items():
            try:
                value = float(entry.get())
            except ValueError:
                messagebox.showerror("Hata", "Geçersiz giriş!")
                return
            new_variables.append(value)
        X_new = np.array(new_variables).reshape(1, -1)

        X_new_poly = poly_features.transform(X_new)
        y_new_pred = model.predict(X_new_poly)

        df_new_data = pd.DataFrame(X_new, columns=df.columns)
        df_new_results = pd.DataFrame({'K+S': y_new_pred.flatten()})
        df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

        result_window = tk.Toplevel(root)
        result_window.title("Tahmin Sonuçları")

        result_label = ttk.Label(result_window, text=df_combined_results)
        result_label.pack(padx=10, pady=10)

    predict_button = ttk.Button(ks_window, text="Tahmin Et", command=predict)
    predict_button.grid(row=len(df.columns), columnspan=2, padx=10, pady=10)

tahmin_sorusu()
