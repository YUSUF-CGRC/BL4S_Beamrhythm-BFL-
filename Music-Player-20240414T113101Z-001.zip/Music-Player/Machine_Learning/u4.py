import tkinter as tk
from tkinter import simpledialog
import numpy as np
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
import os

def get_setup_choice():
    root = tk.Tk()
    root.withdraw()  # Pencereyi gizle
    return simpledialog.askinteger("Setup Seçimi", "Hangi setup için girdi almak istersiniz? (1, 2, 3 veya 4):", minvalue=1, maxvalue=4)

def get_user_input(message):
    root = tk.Tk()
    root.withdraw()  # Pencereyi gizle
    return simpledialog.askfloat("Input", message)

def setup1regressor():
    e_B = get_user_input("e+B:")
    pi_B = get_user_input("pi+B:")
    K_B = get_user_input("K+B:")
    P_B = get_user_input("P+B:")

    data = {
        "e+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "e+P": [0.58, 0.31, 0.18, 0.10, 0.06, 0.05, 0.04, 0.03, 0.03, 0.03],
        "pi+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "pi+P": [0.12, 0.35, 0.47, 0.50, 0.48, 0.40, 0.36, 0.28, 0.20, 0.16],
        "K+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "K+P": [0.00, 0.01, 0.02, 0.02, 0.02, 0.03, 0.02, 0.01, 0.00, 0.00],
        "P+B": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "P+P": [0.12, 0.12, 0.14, 0.24, 0.34, 0.44, 0.54, 0.66, 0.77, 0.83]
    }

    df1 = pd.DataFrame(data)

    X = df1[["e+B", "pi+B", "K+B", "P+B"]].values
    y = df1[["e+P", "pi+P", "K+P", "P+P"]].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = make_pipeline(PolynomialFeatures(degree=5), Ridge(alpha=0.1))
    model.fit(X_train, y_train)

    y_pred = model.predict([[e_B, pi_B, K_B, P_B]])

    variables = ["e+P", "pi+P", "K+P", "P+P"]
    results = {var: pred for var, pred in zip(variables, y_pred[0])}

    # Kullanıcının girdiği verilerle birleştirme
    user_input = {"e+B": e_B, "pi+B": pi_B, "K+B": K_B, "P+B": P_B}
    results.update(user_input)
    return results

def setup2regressor():
    e_B = get_user_input("e+B:")
    pi_B = get_user_input("pi+B:")
    K_B = get_user_input("K+B:")

    data = {
        "e+B": [0.70, 0.40, 0.52, 0.60, 0.70, 0.74, 0.76, 0.82, 0.84, 0.80, 0.85, 0.90],
        "e+P": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14],
        "pi+B": [0.10, 0.38, 0.25, 0.17, 0.10, 0.08, 0.07, 0.06, 0.042, 0.04, 0.02, 0.01],
        "pi+P": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14],
        "K+B": [0.01, 0.010, 0.004, 0.010, 0.010, 0.020, 0.038, 0.040, 0.040, 0.060, 0.040, 0.010],
        "K+P": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14]
    }

    df1 = pd.DataFrame(data)

    X = df1[["e+B", "pi+B", "K+B"]].values
    y = df1[["e+P", "pi+P", "K+P"]].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = make_pipeline(PolynomialFeatures(degree=5), Ridge(alpha=0.1))
    model.fit(X_train, y_train)

    y_pred = model.predict([[e_B, pi_B, K_B]])

    # Tahmin edilen değerleri doğrudan kullanarak bir sözlük oluşturun
    results = {"e+B": e_B, "e+P": y_pred[0][0], "pi+B": pi_B, "pi+P": y_pred[0][1], "K+B": K_B, "K+P": y_pred[0][2]}

    # Sonuçları 'results.csv' dosyasına ekleyin
    results_df = pd.DataFrame([results])
    if not os.path.isfile('results.csv'):
        results_df.to_csv('results.csv', index=False)
    else:
        results_df.to_csv('results.csv', mode='a', index=False, header=False)

    return results



def setup3regressor():
    e_B = get_user_input("e+B:")
    P_B = get_user_input("P+B:")
    pi_B = get_user_input("pi+B:")
    K_B = get_user_input("K+B:")

    data = {
        "e+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "e+S": [22500, 4500, 22300, 22000, 10000, 9000, 8000, 6750, 5000, 3000],
        "P+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "P+S": [6750, 21500, 67500, 100000, 225000, 260000, 275000, 290000, 300000, 500000],
        "pi+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "pi+S": [10000, 67000, 100000, 22500, 225000, 280000, 280000, 270000, 270000, 260000],
        "K+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "K+S": [1000, 120000, 225000, 22500, 22500, 250000, 260000, 265000, 265000, 260000]
    }

    df1 = pd.DataFrame(data)

    X = df1[["e+B", "P+B", "pi+B", "K+B"]].values
    y = df1[["e+S", "P+S", "pi+S", "K+S"]].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = make_pipeline(PolynomialFeatures(degree=5), Ridge(alpha=0.1))
    model.fit(X_train, y_train)

    y_pred = model.predict([[e_B, P_B, pi_B, K_B]])

    variables = ["e+S", "P+S", "pi+S", "K+S"]
    results = {var: pred for var, pred in zip(variables, y_pred[0])}

    # Kullanıcının girdiği verilerle birleştirme
    user_input = {"e+B": e_B, "P+B": P_B, "pi+B": pi_B, "K+B": K_B}
    results.update(user_input)
    return results

def setup4regressor():
    e_B = get_user_input("e+B:")
    P_B = get_user_input("P+B:")
    pi_B = get_user_input("pi+B:")
    K_B = get_user_input("K+B:")

    data = {
        'e+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'e+S': [22500, 23000, 22500, 23750, 12500, 8500, 7000, 5750, 4250, 2000, 1175],
        'P+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'P+S': [0.5, 100.0, 300.0, 500.0, 550.0, 575.0, 450.0, 350.0, 225.0, 100.0, 50.0],
        'pi+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'pi+S': [7500, 22500, 80000, 100000, 150000, 160000, 155000, 135000, 112500, 99000, 85000],
        'K+B': [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00],
        'K+S': [600, 3000, 7500, 9000, 10000, 11000, 9500, 8750, 7300, 7600, 5750],
    }

    df = pd.DataFrame(data)

    X = df[["e+B", "P+B", "pi+B", "K+B"]].values
    y = df[["e+S", "P+S", "pi+S", "K+S"]].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = make_pipeline(PolynomialFeatures(degree=5), Ridge(alpha=0.1))
    model.fit(X_train, y_train)

    y_pred = model.predict([[e_B, P_B, pi_B, K_B]])

    variables = ["e+S", "P+S", "pi+S", "K+S"]
    results = {var: pred for var, pred in zip(variables, y_pred[0])}

    # Kullanıcının girdiği verilerle birleştirme
    user_input = {"e+B": e_B, "P+B": P_B, "pi+B": pi_B, "K+B": K_B}
    results.update(user_input)
    return results
def fix_csv_order(filename, setup_choice):
    # CSV dosyasını oku
    df = pd.read_csv(filename)
    
    # Her bir setup için doğru sıraya göre sütunları yeniden düzenle
    if setup_choice == 1:
        df = df[['e+B', 'e+P', 'pi+B', 'pi+P', 'K+B', 'K+P', 'P+B', 'P+P']]
    elif setup_choice == 2:
        df = df[['e+B','e+P', 'pi+B','pi+P','K+B', 'K+P']]
    elif setup_choice == 3:
        df = df[['e+B', 'e+S', 'pi+B', 'pi+S', 'K+B', 'K+S', 'P+B', 'P+S']]
    elif setup_choice == 4:
        df = df[['e+B', 'e+S', 'pi+B', 'pi+S', 'K+B', 'K+S', 'P+B', 'P+S']]
    
    # Yeni sırayla dosyayı yeniden yaz
    df.to_csv(filename, index=False)


def main():
    setup_choice = get_setup_choice()
    filename = "results.csv"
    
    if setup_choice == 1:
        predicted_values = setup1regressor()
    elif setup_choice == 2:
        predicted_values = setup2regressor()
    elif setup_choice == 3:
        predicted_values = setup3regressor()
    elif setup_choice == 4:
        predicted_values = setup4regressor()
    else:
        print("Geçersiz seçim! Lütfen 1, 2, 3 veya 4 seçeneğinden birini girin.")
        return
    
    # Sonuçları CSV dosyasına yazma
    results_df = pd.DataFrame([predicted_values])
    results_df.to_csv(filename, index=False)
    print(f"Sonuçlar {filename} dosyasına yazıldı.")
    
    # CSV dosyasının sıralamasını düzelt
    fix_csv_order(filename, setup_choice)  # Düzeltildi
    print(f"{filename} dosyasının sıralaması düzeltildi.")

if __name__ == "__main__":
    main()
