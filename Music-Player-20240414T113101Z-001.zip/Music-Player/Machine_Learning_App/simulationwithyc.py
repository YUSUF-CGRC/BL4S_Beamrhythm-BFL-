import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QHBoxLayout, QHeaderView, QMessageBox
from PyQt5 import QtCore
import subprocess
import csv
import os



class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Science creater")
        self.setGeometry(100, 100, 800, 400)  # Pencere boyutunu belirli bir boyutta ayarla

        # Temayı koyu olarak ayarla
        dark_stylesheet = """
            QWidget {
                background-color: #333;
                color: #fff;
            }
            
            QTableWidget {
                background-color: #444;
                color: #fff;
                gridline-color: #fff;
                alternate-background-color: #555;
            }
            
            QHeaderView {
                background-color: #222;
                color: #fff;
            }
            
            QPushButton {
                background-color: #555;
                color: #fff;
                border: 1px solid #777;
                border-radius: 5px;
                padding: 5px;
            }
            
            QPushButton:hover {
                background-color: #666;
            }
            
            QPushButton:pressed {
                background-color: #333;
            }
        """

        # Stil sayfasını uygula
        self.setStyleSheet(dark_stylesheet)

        # Tablo oluştur
        self.tableWidget = QTableWidget()
        self.tableWidget.setRowCount(10)  # Başlangıçta satır sayısını 10'a ayarla
        self.tableWidget.setColumnCount(8)  # Sütun sayısını 8'e ayarla

        # Tablo boyutunu sabitle ve yatay kaydırma çubuğunu etkinleştir
        self.tableWidget.setFixedWidth(600)  # Tablo genişliğini belirli bir boyutta sabitle
        self.tableWidget.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)  # Yatay kaydırma çubuğunu etkinleştir
        self.tableWidget.verticalHeader().setVisible(False)  # Dikey başlık sütununu gizle
        
        # Sütun başlıklarını koyu siyah yap
        header = self.tableWidget.horizontalHeader()
        header.setStyleSheet("color: #000; background-color: #222;")

        # Butonları oluştur
        self.button_layout = QHBoxLayout()

        button1 = QPushButton("S1(7to1)")
        button1.clicked.connect(self.button1_clicked)
        self.button_layout.addWidget(button1)

        button2 = QPushButton("S2(7to1)")
        button2.clicked.connect(self.button2_clicked)
        self.button_layout.addWidget(button2)

        button3 = QPushButton("S3(7 to 1)")
        button3.clicked.connect(self.button3_clicked)
        self.button_layout.addWidget(button3)

        button4 = QPushButton("S4(7 to 1)")
        button4.clicked.connect(self.button4_clicked)
        self.button_layout.addWidget(button4)

        button5 = QPushButton("4 to 4")
        button5.clicked.connect(self.button5_clicked)
        self.button_layout.addWidget(button5)

        # Büyük butonu oluştur
        self.big_button = QPushButton("Csv down")
        self.big_button.clicked.connect(self.big_button_clicked)
        self.button_layout.addWidget(self.big_button)

        # Ana pencere düzeni
        main_layout = QVBoxLayout()
        main_layout.addWidget(self.tableWidget)
        main_layout.addLayout(self.button_layout)

        # Tablo ve butonları ortala
        main_layout.setAlignment(self.tableWidget, QtCore.Qt.AlignHCenter)
        main_layout.setAlignment(self.button_layout, QtCore.Qt.AlignHCenter)

        self.setLayout(main_layout)
    


    

    def save_table_to_csv(self,tableWidget, filename):
     # Create a list to store each row
     rows = []

     # Iterate over each row
     for i in range(tableWidget.rowCount()):
        row = []
        # Iterate over each column in the row
        for j in range(tableWidget.columnCount()):
            item = tableWidget.item(i, j)
            # If the item is not None, add its text to the row list
            if item is not None:
                row.append(item.text())
            else:
                row.append('')
        # Add the row to the rows list
        rows.append(row)

     # Write rows to CSV file
     with open(filename, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(rows)

     # Add this line to the big_button_clicked function


    def big_button_clicked(self):
     print("indir")
     self.save_table_to_csv(self.tableWidget, 'table.csv')
     print("Table data has been saved to 'table.csv'")



    def button1_clicked(self):
        print("S1")
        # İlgili butona göre bir işlem yapılabilir
        # Örneğin, her buton için farklı bir işlev tanımlanabilir.
        subprocess.Popen(["python", r"Machine_Learning\setup1s.py"])

    def button2_clicked(self):
        print("S2")
        # İlgili butona göre bir işlem yapılabilir
        # Örneğin, her buton için farklı bir işlev tanımlanabilir.
        subprocess.Popen(["python", r"Machine_Learning\setup2s.py"])
        
    def button3_clicked(self):
        print("S3")
        # İlgili butona göre bir işlem yapılabilir
        # Örneğin, her buton için farklı bir işlev tanımlanabilir.
        subprocess.Popen(["python", r"Machine_Learning\setup3s.py"])

    def button4_clicked(self):
        print("S4")
        # İlgili butona göre bir işlem yapılabilir
        # Örneğin, her buton için farklı bir işlev tanımlanabilir.
        subprocess.Popen(["python", r"Machine_Learning\setup4s.py"])

    def button5_clicked(self):
        print("4-4")
        # İlgili butona göre bir işlem yapılabilir
        # Örneğin, her buton için farklı bir işlev tanımlanabilir.
        process = subprocess.Popen(["python", r"Machine_Learning\u4.py"])


    
    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
